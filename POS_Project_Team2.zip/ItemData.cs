﻿namespace POS_Project_Team2
{
}

namespace POS_Project_Team2
{
}

namespace POS_Project_Team2
{
}

namespace POS_Project_Team2
{
}

namespace POS_Project_Team2
{
}

namespace POS_Project_Team2
{
}

namespace POS_Project_Team2
{
}

namespace POS_Project_Team2
{
}

namespace POS_Project_Team2
{
}

namespace POS_Project_Team2
{
}

namespace POS_Project_Team2
{
}

namespace POS_Project_Team2
{
}

namespace POS_Project_Team2
{
}

namespace POS_Project_Team2
{
}

namespace POS_Project_Team2
{
}

namespace POS_Project_Team2
{
}

namespace POS_Project_Team2
{
}

public partial class ItemData {
}
